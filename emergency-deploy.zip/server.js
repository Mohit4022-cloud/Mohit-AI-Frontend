const http=require("http");http.createServer((req,res)=>{res.writeHead(200);res.end("MohitAI Mobile Optimized - Deployment in Progress")}).listen(process.env.PORT||8080)
